<div class="post">
    <h3><?= htmlspecialchars($post['id']) ?></h3>
    <p><?= nl2br(htmlspecialchars($post['name'])) ?></p>
</div>