<div class="user">
    <h3><?= htmlspecialchars($user['name']) ?></h3>
    <p><?= nl2br(htmlspecialchars($user['registered_at'])) ?></p>
</div>